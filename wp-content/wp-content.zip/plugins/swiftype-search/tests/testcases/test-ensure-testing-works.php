<?php

class EnsureTestingWorksTest extends SwiftypeTestCase {
  // Simple test to make sure testing framework actually works
	function test_tests() {
		$this->assertTrue( true );
	}
}
