window['$stjq'] = jQuery.noConflict(true);

(function(jQuery) {
