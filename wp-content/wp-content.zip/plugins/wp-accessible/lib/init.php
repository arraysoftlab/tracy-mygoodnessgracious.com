<?php
/**
 * Includes WP Accessible library files
 *
 */

/** Load Widgets */
require_once( WPACC_PATH.'lib/widgets/wpacc-accessible-twitter-feed-widget.php' );