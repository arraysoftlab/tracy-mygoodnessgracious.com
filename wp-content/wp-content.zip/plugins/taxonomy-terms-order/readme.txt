=== Category Order and Taxonomy Terms Order  ===
Contributors: Nsp Code
Donate link: http://www.nsp-code.com/donate.php
Tags: category order,terms order, taxonomy order, admin order
Requires at least: 2.8
Tested up to: 3.9

Order Categories and all custom taxonomies terms (hierarchically) and child terms using a Drag and Drop Sortable javascript capability. No Theme update is required.

== Description ==

Order Categories and all custom taxonomies terms (hierarchically) using a Drag and Drop Sortable javascript capability. <strong>No Theme update is required</strong> the code will change the query on the fly.
If multiple taxonomies are created for a custom post type, a menu will allow to chose the one need sorted. If child categories (terms) are defined, tose can be sorder too using the same interface
<br />Also you can have the admin terms interface sorted per your new sort.
<br />This plugin is developed by <a target="_blank" href="http://www.nsp-code.com">Nsp-Code</a>

== Installation ==

1. Upload `taxonomy-terms-order` folder to your `/wp-content/plugins/` directory.
2. Activate the plugin from Admin > Plugins menu.
3. Once activated you should check with Settings > Taxonomy Terms Order 
4. Use Taxonomy Order link which appear into each post type section to make your sort.

== Screenshots ==

1. Category Order Interface.
2. Multiple Taxonomies Interface.

== Frequently Asked Questions  ==

Feel free to contact me at electronice_delphi@yahoo.com

= I have no PHP knowledge at all, i will still be able to use this plugin? =

Yes, this is the right tool for you. The plugin come with a unique feature to update the queries on the fly and return the terms in the required ored without changing any line of code. Or as alternative you can do that manually.

= What taxonomies will allow me to sort? =

You can sort ALL taxonomies, including the default Categories.

= Is there any way i can get my admin interface to use the custom terms order? =

Absolutelly, the plugin can do that. In fact you can configure so only the admin will update and the front side template will display the terms as before.

= There is a feature that i want it implemented, can you do something about it? =

All ideas are welcome and i put them on my list to be implemented into the new versions. Anyway this may take time, but if you are in a rush, please consider a small donation and we can arrange something.

== Change Log ==

= 1.4.0 = 
 - Hungarian Language(Adam Laki - http://codeguide.hu/)
 - Ukrainian translation (Michael Yunat - http://getvoip.com)
 - Czech translation

= 1.3.7 = 
 - Brazilian Portuguese Language (Rafael Forcadell - www.rafaelforcadell.com.br)

= 1.3.6 =
 - Traditional Chineze Language (Danny - http://sofree.cc)
 - Minor admin styling
   
= 1.3.4 =
 - Menu walker update
 - Translations load fix
 - Japanese language

= 1.3.0 = 
 - Headers already sent bug fix
 - Slovak Language (Branco Slovak http://webhostinggeeks.com/user-reviews/)

= 1.2.9 = 
 - Small updates
 - German and French languages.

= 1.2.7 = 
 - Localisation Implement, Dutch and Romanian.
 - Many thanks to Anja Fokker  http://www.werkgroepen.net/

 
== Upgrade Notice ==

Make sure you get the latest version


== Localization ==

Available in English, Dutch, French, Deutch, Slovak, Japanese, Traditional Chineze, Brazilian Portuguese, Hungarian, Ukrainian, Czech and Romanian
Whant to contribute with a translation to your language? Please use the attached to.pot file 
